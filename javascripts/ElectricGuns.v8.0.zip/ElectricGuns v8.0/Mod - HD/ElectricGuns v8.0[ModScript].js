//ElectricGuns By ElectricDroid11//
//Copyright© 2016//
var smg87 = false;var smg11 = false;var smg12 = false;var smg13 = false;var smg14 = false;var smg15 = false;var smg16 = false;var smg17 = false;var smg18 = false;var smg19 = false;var smg20 = false;var smg21 = false;var smg22 = false;var smg = false;var smg2 = false;var smg3 = false;var smg4 = false;var smg5 = false;var smg6 = false;var smg7 = false;var smg8 = false;var smg9 = false;var xx,yy,zz;var imgview;var ctx;var simpleGui;var C4;var blockx;var blocky;var blockz;var hand = false;var on = false;var INV;var setItem = ModPE.setItem;var SNIPERZOOM;var SNIPERFIRE;var hand2 = false;var hand3 = false;var hand5 = false;var zoom = false;var GUI;var PUNTERO;var exitUI;var compras = [[["$100 Dolares", 510, 1],["Kit Medico", 505, 3]],[["$300 Dolares", 510, 3],["Katana", 500, 1]],[["$500 Dolares", 510, 5],["Katana Gold Edition", 508, 1]],[["$800 Dolares", 510, 8],["Electric M4", 502, 1]],[["$1000 Dolares", 510, 10],["Bazooka", 503, 1]],[["$1200 Dolares", 510, 12],["Bazooka Gold Edition", 515, 1]],[["$200 Dolares", 510, 2]],[["$400 Dolares", 510, 4],["Granada", 516, 1]],[["$1400 Dolares", 510, 14],["IceBall Bazooka", 517, 1]],[["$600 Dolares", 510, 6],["Magnum", 519, 1]],[["$900 Dolares", 510, 9],["M16a4", 520, 1]],[["$900 Dolares", 510, 9],["AUG", 521, 1]],[["$500 Dolares", 510, 5],["Detonador", 530, 1]],[["$700 Dolares", 510, 7],["C4", 230, 1]],[["$900 Dolares", 510, 9],["Ak47", 522, 1]],[["$600 Dolares", 510, 6],["Desert Eagle", 523, 1]],[["$700 Dolares", 510, 7],["Desert Eagle Gold", 524, 1]],[["$900 Dolares", 510, 9],["RPK", 526, 1]],[["$700 Dolares", 510, 7],["R870", 527, 1]],[["$800 Dolares", 510, 8],["MiniUZI", 528, 1]],[["$2000 Dolares", 510, 20],["ThunderGun", 551, 1]],[["$1000 Dolares", 510, 10],["Sniper", 552, 1]],[["$900 Dolares", 510, 9],["M72", 553, 1]],[["$5000 Dolares", 510, 50],["Double MiniGun", 554, 1]],[["$5000 Dolares", 510, 50],["Double Bazooka", 555, 1]],[["$1200 Dolares", 510, 12],["M14", 556, 1]],[["$1200 Dolares", 510, 12],["M1887", 557, 1]],[["$1000 Dolares", 510, 10],["Double Glock", 558, 1]],[["$700 Dolares", 510, 7],["Excalibur", 559, 1]],[["$1000 Dolares", 510, 10],["Double UZI", 560, 1]],[["$1200 Dolares", 510, 12],["HK417", 561, 1]],[["$1300 Dolares", 510, 13],["SG551", 562, 1]],[["$1100 Dolares", 510, 11],["P90", 563, 1]],[["$1200 Dolares", 510, 12],["Super90", 564, 1]],[["$1100 Dolares", 510, 11],["Famas", 565, 1]],[["$1100 Dolares", 510, 11],["MP5", 566, 1]],[["$1300 Dolares", 510, 13],["SIG-552", 567, 1]],[["$1400 Dolares", 510, 14],["Galil", 568, 1]],[["$1400 Dolares", 510, 14],["Guitar", 559, 1]],[["$1300 Dolares", 510, 13],["MachineGun", 570, 1]],[["$700 Dolares", 510, 7],["FiveSeven", 571, 1]],[["$2300 Dolares", 510, 23],["Bulk Cannon", 572, 1]],[["$3000 Dolares", 510, 30],["MiniGun Explosive", 573, 1]],[["$1100 Dolares", 510, 11],["Scar", 574, 1]],[["$1200 Dolares", 510, 12],["Combat Shotgun", 575, 1]],[["$1200 Dolares", 510, 12],["Pump Shotgun", 576, 1]],[["$1000 Dolares", 510, 10],["Lanzagranadas", 577, 1]],[["$1100 Dolares", 510,11],["Escopeta Recortada", 578, 1]],[["$2000 Dolares", 510,20],["Jetpack", 579, 1]],[["$1000 Dolares", 510,10],["Experience Gun", 580, 1]],[["$2000 Dolares", 510,20],["Diamond Gun", 581, 1]],[["$1800 Dolares", 510,18],["Gold Gun", 582, 1]],[["$1700 Dolares", 510,17],["Iron Gun", 583, 1]],[["$1000 Dolares", 510,10],["Pig Gun", 584, 1]],[["$1500 Dolares", 510,15],["Zeus X27", 585, 1]],[["EnderPearl", 476,10],["EnderGun", 588, 1]],[["$1000 Dolares", 510,10],["Luger PO8", 586, 1]],[["$1500 Dolares", 510,15],["MP40", 587, 1]],[["$1000 Dolares", 510,10],["Binoculars", 589, 1]]];
var hand31 = false;var playerDir = [0, 0, 0];var DEG_TO_RAD = Math.PI / 180;var playerFlySpeed = 1;var smg80 = false;var smg81 = false;var smg82 = false;var smg83 = false;var smg84 = false;var ePearls = [];var hand88 = false;var bin;var NPCmenu;var NPCexitUI;var hand89 = false;
ModPE.setItem(600,"huevo",0,"SpawnNPC", 64);
Item.addShapedRecipe(600,1,0,["ooo","oeo","ooo"],["o",49,0,"e",388,0,]);
ModPE.setItem(510, "dolar", 0, "$100 Dolares");Item.addShapedRecipe(510,1,0,[
"   ","121","   "],["1",339,0,"2",339,0,]);
ModPE.setItem(500, "cuchillo", 0, "Knife", 1);
Item.setHandEquipped(500, true);
ModPE.setItem(502, "m4", 0, "Electric M4", 1);
Item.setHandEquipped(502, true);
ModPE.setItem(503,"bazooka",0,"Bazooka", 1);
Item.setHandEquipped(503, true);
ModPE.setFoodItem(505, "kit", 0, 20,"Kit Medico");
ModPE.setItem(508, "gold" , 0, "Katana Gold Edition", 1);
Item.setHandEquipped(508, true);
ModPE.setItem(515, "gold2" , 0, "Bazooka Gold Edition", 1);
Item.setHandEquipped(515, true);
Item.defineThrowable(516, "granada", 0, "Granada", 1);
ModPE.setItem(517, "iceballb", 0, "IceBall Bazooka", 1);
Item.setHandEquipped(517, true);
ModPE.setItem(519, "magnum", 0, "Magnum", 1);
Item.setHandEquipped(519, true);
ModPE.setItem(520, "aug", 0, "AUG", 1);
Item.setHandEquipped(520, true);
ModPE.setItem(521, "m16", 0, "M16a4", 1);
Item.setHandEquipped(521, true);
ModPE.setItem(530, "detonador", 0, "Detonador");
Item.setHandEquipped(530,true);
Block.defineBlock(230,"C4","c4",3,false,0);
Block.setRenderLayer(230,1);
Block.setShape(230,0,0,0,1,0.05,1);
ModPE.setItem(522, "ak47", 0, "Ak47", 1);
Item.setHandEquipped(522, true);
ModPE.setItem(523, "deserteagle", 0, "Desert Eagle", 1);Item.setHandEquipped(523, true);
ModPE.setItem(524, "deserteaglegold", 0, "Desert Eagle Gold", 1);Item.setHandEquipped(524, true);
ModPE.setItem(526, "rpk", 0, "RPK", 1);
Item.setHandEquipped(526, true);
ModPE.setItem(527, "r870", 0, "R870", 1);
Item.setHandEquipped(527, true);
ModPE.setItem(528, "miniuzi", 0, "UZI", 1);
Item.setHandEquipped(528, true);
ModPE.setItem(529, "minigun", 0, "MiniGun", 1);
Item.setHandEquipped(529, true);
var thunderID = 551;var thunderITEM = ModPE.setItem;
thunderITEM(thunderID, "thundergun", 0, "§a§5ThunderGun", 1);
Item.setHandEquipped(551, true);
ModPE.setItem(552, "m21", 0,"Sniper",1);
Item.setHandEquipped(552, true);
ModPE.setItem(553,"m72",0,"M72",1);
Item.setHandEquipped(553, true);
setItem(554,"minigun2",0,"Double MiniGun", 1);
Item.setHandEquipped(554, true);
setItem(555,"bazooka2",0,"Double Bazooka",1);
Item.setHandEquipped(555, true);
setItem(556,"m14",0,"M14",1);
Item.setHandEquipped(556, true);
setItem(557,"m1887",0,"M1887",1);
Item.setHandEquipped(557, true);
setItem(558,"glock2",0,"Double Glock",1);
Item.setHandEquipped(558, true);
setItem(559,"excalibur",0,"Excalibur",1);
Item.setHandEquipped(559, true);
setItem(560,"uzi2",0,"Double UZI",1);
Item.setHandEquipped(560,true);
setItem(561,"hk417",0,"HK417",1);
Item.setHandEquipped(561,true);
setItem(562,"sg551",0,"SG551",1);
Item.setHandEquipped(562,true);
setItem(563,"p90",0,"P90",1);
Item.setHandEquipped(563,true);
setItem(564,"super90",0,"Super90",1);
Item.setHandEquipped(564,true);
setItem(565,"famas",0,"Famas",1);
Item.setHandEquipped(565,true);
setItem(566,"mp5",0,"MP5",1);
Item.setHandEquipped(566,true);
setItem(567,"sig-552",0,"SIG-552",1);
Item.setHandEquipped(567,true);
setItem(568,"galil",0,"Galil",1);
Item.setHandEquipped(568,true);
setItem(569,"guitar",0,"Guitar",1);
Item.setHandEquipped(569,true);
setItem(570,"machinegun",0,"MachineGun",1);
Item.setHandEquipped(570,true);
setItem(571,"fiveseven",0,"FiveSeven",1);
Item.setHandEquipped(571,true);
setItem(572,"bulk",0,"Bulk Cannon",1);
Item.setHandEquipped(572,true);
setItem(573,"minigun3",0,"MiniGun Explosive",1);
Item.setHandEquipped(573,true);
setItem(574,"scar",0,"Scar",1); Item.setHandEquipped(574,true);
setItem(575,"cshotgun",0,"Combat Shotgun",1); Item.setHandEquipped(575,true); setItem(576,"pshotgun",0,"Pump Shotgun",1); Item.setHandEquipped(576,true);
setItem(577,"lanzag",0,"LanzaGranadas",1); Item.setHandEquipped(577,true); setItem(578,"rshotgun",0,"Escopeta Recortada",1); Item.setHandEquipped(578,true);
setItem(579,"jetpack",0,"JetPack",1);
Item.defineArmor(999, "jetpack", 0, "JetPack_Armor", "images/armor/jetpack_1.png", 0, 100, ArmorType.chestplate);
setItem(580,"xpGun",0,"Experience Gun",1);
Item.setHandEquipped(580, true);
setItem(581,"diamondgun",0,"Diamond Gun",1);
Item.setHandEquipped(581, true);
setItem(582,"goldgun",0,"Gold Gun",1);
Item.setHandEquipped(582, true);
setItem(583,"irongun",0,"Iron Gun",1);
Item.setHandEquipped(583, true);
setItem(584,"piggun",0,"Pig Gun",1);
Item.setHandEquipped(584, true);
setItem(585,"zeusX27", 0," Zeus X27",1);
Item.setHandEquipped(585, true);
setItem(586,"lugerPO8",0,"Luger PO8",1);
Item.setHandEquipped(586,true);
setItem(587,"mp40",0,"MP40",1);
Item.setHandEquipped(587,true);
setItem(588,"ED",0,"EnderGun",1);
Item.setHandEquipped(588,true);
ModPE.setItem(476, "ender_pearl", 0, "Ender Pearl");
setItem(589,"binoculares",0,"Binoculars",1);

ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
function newLevel(){
var x = Player.getX();
var y = Player.getY();
var z = Player.getZ();
function leaveGame() { 
	if(ctx!=null) {
		ctx.runOnUiThread(new java.lang.Runnable({ run: function() {
			try{
				if(simpleGui != null) {
					simpleGui.dismiss();
					simpleGui = null;
				}
			}catch(err){
				print("Error: " + err);
			}
		}}));
	}
}
com.mojang.minecraftpe.MainActivity.currentMainActivity.get().runOnUiThread(new java.lang.Runnable()
	{
		run: function()
		{
			try
			{
				var layout = new android.widget.LinearLayout(com.mojang.minecraftpe.MainActivity.currentMainActivity.get());



				layout.setOrientation(android.widget.LinearLayout.VERTICAL);

				var scroll = new android.widget.ScrollView(com.mojang.minecraftpe.MainActivity.currentMainActivity.get());
				scroll.addView(layout);

				var popup = new android.app.Dialog(com.mojang.minecraftpe.MainActivity.currentMainActivity.get());
				popup.setContentView(scroll);
				popup.setTitle(new android.text.Html.fromHtml("ElectricGuns v8.0"));
				popup.setCanceledOnTouchOutside(false);

				var text = new android.widget.TextView(com.mojang.minecraftpe.MainActivity.currentMainActivity.get());	
          text.setGravity(android.view.Gravity.CENTER);
				text.setText(new android.text.Html.fromHtml("ElectricGuns V8.0 Mod By ElectricDroid11<br>Suscribete A Mi Canal De Youtube: <b>TheElectricDroid11<b/>"));
				layout.addView(text);	

				var dividerText = new android.widget.TextView(com.mojang.minecraftpe.MainActivity.currentMainActivity.get());
				dividerText.setText(" ");
				layout.addView(dividerText);

				var exitButton = new android.widget.Button(com.mojang.minecraftpe.MainActivity.currentMainActivity.get());
				exitButton.setText("Cerrar");
				exitButton.setOnClickListener(new android.view.View.OnClickListener()
				{
					onClick: function()
					{
						textureUiShowed = false;
						popup.dismiss();
					}
				});
				layout.addView(exitButton);


				popup.show();

			} catch(err)
			{
				print("Error: " + err);
			}
		}
	});
}

function addTraderRenderType(Renderer){

var model = Renderer.getModel();
var var2 = 0;

var head = model.getPart("head").clear();
var body = model.getPart("body").clear();
var rArm = model.getPart("rightArm").clear();
var lArm = model.getPart("leftArm").clear();
var rLeg = model.getPart("rightLeg").clear();
var lLeg = model.getPart("leftLeg").clear();

head.clear();
head.setTextureSize(64,64);
head.setTextureOffset(0,0, true);
head.addBox( -4, -8, -4, 8, 8, 8, var2);
//Cigarrillo
head.setTextureSize(64,64);
head.setTextureOffset(24,0, true);
head.addBox( 1, -1, -7, 1, 1, 3, var2);
//Casco1
head.setTextureSize(64,64);
head.setTextureOffset(45,43, true);
head.addBox( -4, -6, -5, 8, 1, 1, var2);
//Casco2
head.setTextureSize(64,64);
head.setTextureOffset(39,6, true);
head.addBox( -4, -5, -5, 8, 8, 1, var2);


body.clear();
//Arma
body.setTextureSize(64,64);
body.setTextureOffset(47,47, true);
body.addBox( -8, -1, 4, 16, 16, 1, var2);
//Cuerpo
body.setTextureSize(64,64);
body.setTextureOffset(16,16, true);
body.addBox( -4, 0, -2, 8, 12, 4, var2);
//Chaleco
body.setTextureSize(64,64);
body.setTextureOffset(0,32, true);
body.addBox( -4, 0, -3, 8, 11, 6, var2);

rArm.clear();
rArm.setTextureSize(64,64);
rArm.setTextureOffset(40,16, true);
rArm.addBox( -2,-2, -2, 4, 12, 4, var2);

lArm.clear();
lArm.setTextureSize(64,64);
lArm.setTextureOffset(29,32, true);
lArm.addBox( -2, -2, -2, 4, 12, 4, var2);

rLeg.clear();
rLeg.setTextureSize(64,64);
rLeg.setTextureOffset(0,16, true);
rLeg.addBox( -2,0, -2, 4, 12, 4, var2);

lLeg.clear();
lLeg.setTextureSize(64,64);
lLeg.setTextureOffset(0,16, true);
lLeg.addBox( -2, 0,-2, 4, 12, 4, var2);

}
var traderRenderType = Renderer.createHumanoidRenderer();
addTraderRenderType(traderRenderType);

//**function useItem(x,y,z,i,b,s){}**//

function customThrowableHitBlockHook(projectile,itemId,x,y,z,side){
if(itemId == 516)
{
explode(x,y,z,5);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.bazooka", 1, 0.5);
}
}

function useItem(x,y,z,itemId,blockId,side)
{
if(itemId==600){
	var trade = Level.spawnMob(x,y+1,z,EntityType.IRON_GOLEM,"images/mob/SkinTrader.png");
	Entity.setRenderType(trade,traderRenderType.renderType);
	Entity.setHealth(trade,160);
    Entity.setNameTag(trade,"[NPC] Trader");
	Entity.setCarriedItem(trade,0,0,0);
	Entity.addEffect(trade, MobEffect.movementSpeed,1000123*20, 9, false, true);
	Entity.addEffect(trade,MobEffect.jump,300*20,1,false,true);
}
if(Player.getCarriedItem() == thunderID){
Level.spawnMob(x,y+1,z,93);
}
if(itemId == 559){
explode(x,y,z,3);
	Level.spawnMob(x+1,y+1,z,93);
	Level.spawnMob(x+2,y+1,z,93);
	Level.spawnMob(x,y+1,z+1,93);
	Level.spawnMob(x,y+1,z+2,93);
	Level.spawnMob(x-1,y+1,z,93);
	Level.spawnMob(x-2,y+1,z,93);
	Level.spawnMob(x,y+1,z-1,93);
	Level.spawnMob(x,y+1,z-2,93);
}
if(smg80 == false && itemId == 580)
{
smg80 = true;
}
else
{
smg80 = false;
}
if(smg81 == false && itemId == 581)
{
smg81 = true;
}
else
{
smg81 = false;
}
if(smg82 == false && itemId == 582)
{
smg82 = true;
}
else
{
smg82 = false;
}
if(smg83 == false && itemId == 583)
{
smg83 = true;
}
else
{
smg83 = false;
}
if(smg84 == false && itemId == 584)
{
smg84 = true;
}
else
{
smg84 = false;
}
if(itemId == 585)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow2 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
setVelX(arrow1,5*xx);
setVelY(arrow1,6*zz);
setVelZ(arrow1,7*yy);
setVelX(arrow2,5*xx);
setVelY(arrow2,4*zz);
setVelZ(arrow2,3*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(itemId == 586)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
setVelX(arrow1,5*xx);
setVelY(arrow1,6*zz);
setVelZ(arrow1,7*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(smg87 == false && itemId == 587)
{
smg87 = true;
}
else
{
smg87 = false;
}
if(smg == false && itemId == 502)
{
smg = true;
}
else
{
smg = false;
}
if(itemId == 503)
{
var pyaw = Entity.getYaw(Player.getEntity());
var ppitch = Entity.getPitch(Player.getEntity());
velY = Math.sin((ppitch - 180) / 180 * Math.PI);
velX = 4 * (Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
velZ = 4 * (-1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
var arrow = Level.spawnMob(Player.getX() + Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,Player.getY(),Player.getZ() + -1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,65);
setVelX(arrow,velX);
setVelY(arrow,velY);
setVelZ(arrow,velZ);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.bazooka", 1, 0.5);
}
if(itemId==571)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
setVelX(arrow1,5*xx);
setVelY(arrow1,5*zz);
setVelZ(arrow1,5*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(itemId==577)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,65);
setVelX(arrow1,5*xx);
setVelY(arrow1,5*zz);
setVelZ(arrow1,5*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(itemId==572)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,65);
arrow1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,65);
arrow2 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,65);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
setVelX(arrow1,5*xx);
setVelY(arrow1,6*zz);
setVelZ(arrow1,7*yy);
setVelX(arrow2,5*xx);
setVelY(arrow2,4*zz);
setVelZ(arrow2,3*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(itemId == 515)
{
var pyaw = Entity.getYaw(Player.getEntity());
var ppitch = Entity.getPitch(Player.getEntity());
velY = Math.sin((ppitch - 180) / 180 * Math.PI);
velX = 4 * (Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
velZ = 4 * (-1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
var arrow = Level.spawnMob(Player.getX() + Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,Player.getY(),Player.getZ() + -1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,65);
setVelX(arrow,velX);
setVelY(arrow,velY);
setVelZ(arrow,velZ);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.bazooka", 1, 0.5);
}
if(itemId == 517)
{
var pyaw = Entity.getYaw(Player.getEntity());
var ppitch = Entity.getPitch(Player.getEntity());
velY = Math.sin((ppitch - 180) / 180 * Math.PI);
velX = 4 * (Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
velZ = 4 * (-1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
var arrow = Level.spawnMob(Player.getX() + Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,Player.getY(),Player.getZ() + -1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,81);
setVelX(arrow,velX);
setVelY(arrow,velY);
setVelZ(arrow,velZ);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.bazooka", 1, 0.5);
}
if(itemId == 519)
{
var pyaw = Entity.getYaw(Player.getEntity());
var ppitch = Entity.getPitch(Player.getEntity());
velY = Math.sin((ppitch - 180) / 180 * Math.PI);
velX = 4 * (Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
velZ = 4 * (-1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
var arrow = Level.spawnMob(Player.getX() + Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,Player.getY(),Player.getZ() + -1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,80);
setVelX(arrow,velX);
setVelY(arrow,velY);
setVelZ(arrow,velZ);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(smg3 == false && itemId == 520)
{
smg3 = true;
}
else
{
smg3 = false;
}
if(smg4 == false && itemId == 521)
{
smg4 = true;
}
else
{
smg4 = false;
}
if(blockId==230&&itemId==530){
blockx = x;
blocky = y;
blockz = z;
ModPE.showTipMessage("C4 Activado!");
on = true;
}
if(smg5 == false && itemId == 522)
{
smg5 = true;
}
else
{
smg5 = false;
}
if(smg6 == false && itemId == 528)
{
smg6 = true;
}
else
{
smg6 = false;
}
if(smg7 == false && itemId == 529)
{
smg7 = true;
}
else
{
smg7 = false;
}
if(smg11 == false && itemId == 560)
{
smg11 = true;
}
else
{
smg11 = false;
}
if(smg12 == false && itemId == 561)
{
smg12 = true;
}
else
{
smg12 = false;
}
if(smg13 == false && itemId == 562)
{
smg13 = true;
}
else
{
smg13 = false;
}
if(smg14 == false && itemId == 563)
{
smg14 = true;
}
else
{
smg14 = false;
}
if(smg15 == false && itemId == 565)
{
smg15 = true;
}
else
{
smg15 = false;
}
if(smg16 == false && itemId == 566)
{
smg16 = true;
}
else
{
smg16 = false;
}
if(smg17 == false && itemId == 567)
{
smg17 = true;
}
else
{
smg17 = false;
}
if(smg18 == false && itemId == 568)
{
smg18 = true;
}
else
{
smg18 = false;
}
if(smg19 == false && itemId == 569)
{
smg19 = true;
}
else
{
smg19 = false;
}
if(smg20 == false && itemId == 570)
{
smg20 = true;
}
else
{
smg20 = false;
}
if(smg21 == false && itemId == 573)
{
smg21 = true;
}
else
{
smg21 = false;
}
if(smg22 == false && itemId == 574)
{
smg22 = true;
}
else
{
smg22 = false;
}
if(itemId == 523)
{
var pyaw = Entity.getYaw(Player.getEntity());
var ppitch = Entity.getPitch(Player.getEntity());
velY = Math.sin((ppitch - 180) / 180 * Math.PI);
velX = 4 * (Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
velZ = 4 * (-1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
var arrow = Level.spawnMob(Player.getX() + Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,Player.getY(),Player.getZ() + -1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,80);
setVelX(arrow,velX);
setVelY(arrow,velY);
setVelZ(arrow,velZ);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(itemId == 524)
{
var pyaw = Entity.getYaw(Player.getEntity());
var ppitch = Entity.getPitch(Player.getEntity());
velY = Math.sin((ppitch - 180) / 180 * Math.PI);
velX = 4 * (Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
velZ = 4 * (-1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
var arrow = Level.spawnMob(Player.getX() + Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,Player.getY(),Player.getZ() + -1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,80);
setVelX(arrow,velX);
setVelY(arrow,velY);
setVelZ(arrow,velZ);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(smg2 == false && itemId == 526)
{
smg2 = true;
}
else
{
smg2 = false;
}
if(itemId == 564)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow2 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow3 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
setVelX(arrow1,5*xx);
setVelY(arrow1,6*zz);
setVelZ(arrow1,7*yy);
setVelX(arrow2,5*xx);
setVelY(arrow2,4*zz);
setVelZ(arrow2,3*yy);
setVelX(arrow3,6*xx);
setVelY(arrow3,5*zz);
setVelZ(arrow3,7*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(itemId == 575)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow2 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow3 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
setVelX(arrow1,5*xx);
setVelY(arrow1,6*zz);
setVelZ(arrow1,7*yy);
setVelX(arrow2,5*xx);
setVelY(arrow2,4*zz);
setVelZ(arrow2,3*yy);
setVelX(arrow3,6*xx);
setVelY(arrow3,5*zz);
setVelZ(arrow3,7*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(itemId == 576)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow2 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow3 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
setVelX(arrow1,5*xx);
setVelY(arrow1,6*zz);
setVelZ(arrow1,7*yy);
setVelX(arrow2,5*xx);
setVelY(arrow2,4*zz);
setVelZ(arrow2,3*yy);
setVelX(arrow3,6*xx);
setVelY(arrow3,5*zz);
setVelZ(arrow3,7*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(itemId == 578)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow2 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow3 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
setVelX(arrow1,5*xx);
setVelY(arrow1,6*zz);
setVelZ(arrow1,7*yy);
setVelX(arrow2,5*xx);
setVelY(arrow2,4*zz);
setVelZ(arrow2,3*yy);
setVelX(arrow3,6*xx);
setVelY(arrow3,5*zz);
setVelZ(arrow3,7*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(itemId == 527)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow2 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow3 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
setVelX(arrow1,5*xx);
setVelY(arrow1,6*zz);
setVelZ(arrow1,7*yy);
setVelX(arrow2,5*xx);
setVelY(arrow2,4*zz);
setVelZ(arrow2,3*yy);
setVelX(arrow3,6*xx);
setVelY(arrow3,5*zz);
setVelZ(arrow3,7*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(itemId == 553)
{
var pyaw = Entity.getYaw(Player.getEntity());
var ppitch = Entity.getPitch(Player.getEntity());
velY = Math.sin((ppitch - 180) / 180 * Math.PI);
velX = 4 * (Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
velZ = 4 * (-1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
var arrow = Level.spawnMob(Player.getX() + Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,Player.getY(),Player.getZ() + -1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,65);
setVelX(arrow,velX);
setVelY(arrow,velY);
setVelZ(arrow,velZ);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.bazooka", 1, 0.5);
}
if(smg8 == false && itemId == 554)
{
smg8 = true;
}
else
{
smg8 = false;
}
if(itemId == 555){
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
tnt = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,65);
tnt1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,65);
tnt2 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,65);
tnt3 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,65);
setVelX(tnt,5*xx);
setVelY(tnt,5*zz);
setVelZ(tnt,5*yy);
setVelX(tnt1,5*xx);
setVelY(tnt1,6*zz);
setVelZ(tnt1,7*yy);
setVelX(tnt2,5*xx);
setVelY(tnt2,4*zz);
setVelZ(tnt2,3*yy);
setVelX(tnt3,6*xx);
setVelY(tnt3,5*zz);
setVelZ(tnt3,7*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(itemId==556)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow2 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow3 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
setVelX(arrow1,5*xx);
setVelY(arrow1,6*zz);
setVelZ(arrow1,7*yy);
setVelX(arrow2,5*xx);
setVelY(arrow2,4*zz);
setVelZ(arrow2,3*yy);
setVelX(arrow3,6*xx);
setVelY(arrow3,5*zz);
setVelZ(arrow3,7*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 100, 0.5);
}
if(itemId==557){
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow2 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow3 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
setVelX(arrow1,5*xx);
setVelY(arrow1,6*zz);
setVelZ(arrow1,7*yy);
setVelX(arrow2,5*xx);
setVelY(arrow2,4*zz);
setVelZ(arrow2,3*yy);
setVelX(arrow3,6*xx);
setVelY(arrow3,5*zz);
setVelZ(arrow3,7*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(itemId==558){
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
setVelX(arrow1,5*xx);
setVelY(arrow1,6*zz);
setVelZ(arrow1,7*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
}


function attackHook(attacker,victim)
{
x = Entity.getX(victim);
y = Entity.getY(victim);
z = Entity.getZ(victim);

if(Player.getCarriedItem()==500)
{
Entity.setHealth(victim,Entity.getHealth(victim)-15);
}
if(Player.getCarriedItem()==508)
{
Entity.setHealth(victim,Entity.getHealth(victim)-20);
}
if(Player.getCarriedItem() == 540){
Entity.setFireTicks(victim,100);
}

}


function modTick(){for (i = 0; i < ePearls.length; i++) {
epX = Entity.getX(ePearls[i]);
epY = Entity.getY(ePearls[i]);
epZ = Entity.getZ(ePearls[i]);
if (getTile(epX, epY - 1, epZ) != 0 || getTile(epX, epY + 1, epZ) != 0 || getTile(epX - 1, epY, epZ) != 0 || getTile(epX + 1, epY, epZ) != 0 || getTile(epX, epY, epZ - 1) != 0 || getTile(epX, epY, epZ + 1) != 0) {
Entity.setPosition(Player.getEntity(), Entity.getX(ePearls[i]), Entity.getY(ePearls[i]) + 1, Entity.getZ(ePearls[i]));
Entity.remove(ePearls[i]);
ePearls.splice(i, 1);
}
}
if(Player.getCarriedItem() == 579 && hand31 == false) {
hand31 = true;
Player.setArmorSlot(1, 999, 0);
}
else if(Player.getCarriedItem() != 579 && hand31 == true) {
hand31 = false;
Player.setArmorSlot(1, -999, 0);
}
if(getCarriedItem() == 579){
jetpackTick();
}
if(smg80 == true && Player.getCarriedItem()==580)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx, Player.getY()+zz, Player.getZ()+yy, 69);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(smg81 == true && Player.getCarriedItem()==581)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.dropItem(Player.getX()+xx, Player.getY()+zz, Player.getZ()+yy, 0, 264, 1);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(smg82 == true && Player.getCarriedItem()==582)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.dropItem(Player.getX()+xx, Player.getY()+zz, Player.getZ()+yy, 0, 266, 1);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(smg83 == true && Player.getCarriedItem()==583)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.dropItem(Player.getX()+xx, Player.getY()+zz, Player.getZ()+yy, 0, 265, 1);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(smg87 == true && Player.getCarriedItem()==587)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx, Player.getY()+zz, Player.getZ()+yy, 80);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(smg84 == true && Player.getCarriedItem()==584)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx, Player.getY()+zz, Player.getZ()+yy, 12);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(smg == true && Player.getCarriedItem()==502)
{
var pyaw = Entity.getYaw(Player.getEntity()); 
var ppitch = Entity.getPitch(Player.getEntity());
velY = Math.sin((ppitch - 180) / 180 * Math.PI); 
velX = 3.2 * (Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
velZ = 3.2 * (-1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
var arrow = Level.spawnMob(Player.getX() + Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,Player.getY(),Player.getZ() + -1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,80);
setVelX(arrow,velX);
setVelY(arrow,velY);
setVelZ(arrow,velZ);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
else
{
smg = false;
}
if(smg2 == true && Player.getCarriedItem()==526)
{
var pyaw = Entity.getYaw(Player.getEntity()); 
var ppitch = Entity.getPitch(Player.getEntity());
velY = Math.sin((ppitch - 180) / 180 * Math.PI); 
velX = 4.0 * (Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
velZ = 4.0 * (-1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
var arrow = Level.spawnMob(Player.getX() + Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,Player.getY(),Player.getZ() + -1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,80);
setVelX(arrow,velX);
setVelY(arrow,velY);
setVelZ(arrow,velZ);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
else
{
smg2 = false;
}
if(smg8 == true && Player.getCarriedItem()==554)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow2 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow3 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
setVelX(arrow1,5*xx);
setVelY(arrow1,6*zz);
setVelZ(arrow1,7*yy);
setVelX(arrow2,5*xx);
setVelY(arrow2,4*zz);
setVelZ(arrow2,3*yy);
setVelX(arrow3,6*xx);
setVelY(arrow3,5*zz);
setVelZ(arrow3,7*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(smg11 == true && Player.getCarriedItem()==560)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow2 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow3 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
setVelX(arrow1,5*xx);
setVelY(arrow1,6*zz);
setVelZ(arrow1,7*yy);
setVelX(arrow2,5*xx);
setVelY(arrow2,4*zz);
setVelZ(arrow2,3*yy);
setVelX(arrow3,6*xx);
setVelY(arrow3,5*zz);
setVelZ(arrow3,7*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(smg12 == true && Player.getCarriedItem()==561)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow2 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow3 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
setVelX(arrow1,5*xx);
setVelY(arrow1,6*zz);
setVelZ(arrow1,7*yy);
setVelX(arrow2,5*xx);
setVelY(arrow2,4*zz);
setVelZ(arrow2,3*yy);
setVelX(arrow3,6*xx);
setVelY(arrow3,5*zz);
setVelZ(arrow3,7*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(smg13 == true && Player.getCarriedItem()==562)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180;
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow2 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow3 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
setVelX(arrow1,5*xx);
setVelY(arrow1,6*zz);
setVelZ(arrow1,7*yy);
setVelX(arrow2,5*xx);
setVelY(arrow2,4*zz);
setVelZ(arrow2,3*yy);
setVelX(arrow3,6*xx);
setVelY(arrow3,5*zz);
setVelZ(arrow3,7*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(smg14 == true && Player.getCarriedItem()==563)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow2 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow3 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
setVelX(arrow1,5*xx);
setVelY(arrow1,6*zz);
setVelZ(arrow1,7*yy);
setVelX(arrow2,5*xx);
setVelY(arrow2,4*zz);
setVelZ(arrow2,3*yy);
setVelX(arrow3,6*xx);
setVelY(arrow3,5*zz);
setVelZ(arrow3,7*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(smg15 == true && Player.getCarriedItem()==565)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow2 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow3 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
setVelX(arrow1,5*xx);
setVelY(arrow1,6*zz);
setVelZ(arrow1,7*yy);
setVelX(arrow2,5*xx);
setVelY(arrow2,4*zz);
setVelZ(arrow2,3*yy);
setVelX(arrow3,6*xx);
setVelY(arrow3,5*zz);
setVelZ(arrow3,7*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(smg16 == true && Player.getCarriedItem()==566)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow2 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow3 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
setVelX(arrow1,5*xx);
setVelY(arrow1,6*zz);
setVelZ(arrow1,7*yy);
setVelX(arrow2,5*xx);
setVelY(arrow2,4*zz);
setVelZ(arrow2,3*yy);
setVelX(arrow3,6*xx);
setVelY(arrow3,5*zz);
setVelZ(arrow3,7*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(smg17 == true && Player.getCarriedItem()==567)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow2 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow3 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
setVelX(arrow1,5*xx);
setVelY(arrow1,6*zz);
setVelZ(arrow1,7*yy);
setVelX(arrow2,5*xx);
setVelY(arrow2,4*zz);
setVelZ(arrow2,3*yy);
setVelX(arrow3,6*xx);
setVelY(arrow3,5*zz);
setVelZ(arrow3,7*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(smg18 == true && Player.getCarriedItem()==568)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow2 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow3 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
setVelX(arrow1,5*xx);
setVelY(arrow1,6*zz);
setVelZ(arrow1,7*yy);
setVelX(arrow2,5*xx);
setVelY(arrow2,4*zz);
setVelZ(arrow2,3*yy);
setVelX(arrow3,6*xx);
setVelY(arrow3,5*zz);
setVelZ(arrow3,7*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(smg19 == true && Player.getCarriedItem()==569)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow2 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow3 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
setVelX(arrow1,5*xx);
setVelY(arrow1,6*zz);
setVelZ(arrow1,7*yy);
setVelX(arrow2,5*xx);
setVelY(arrow2,4*zz);
setVelZ(arrow2,3*yy);
setVelX(arrow3,6*xx);
setVelY(arrow3,5*zz);
setVelZ(arrow3,7*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(smg20 == true && Player.getCarriedItem()==570)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow2 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow3 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
setVelX(arrow1,5*xx);
setVelY(arrow1,6*zz);
setVelZ(arrow1,7*yy);
setVelX(arrow2,5*xx);
setVelY(arrow2,4*zz);
setVelZ(arrow2,3*yy);
setVelX(arrow3,6*xx);
setVelY(arrow3,5*zz);
setVelZ(arrow3,7*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(smg21 == true && Player.getCarriedItem()==573)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,65);
arrow1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,65);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
setVelX(arrow1,5*xx);
setVelY(arrow1,6*zz);
setVelZ(arrow1,7*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(smg22 == true && Player.getCarriedItem()==574)
{
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow2 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
arrow3 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
setVelX(arrow,5*xx);
setVelY(arrow,5*zz);
setVelZ(arrow,5*yy);
setVelX(arrow1,5*xx);
setVelY(arrow1,6*zz);
setVelZ(arrow1,7*yy);
setVelX(arrow2,5*xx);
setVelY(arrow2,4*zz);
setVelZ(arrow2,3*yy);
setVelX(arrow3,6*xx);
setVelY(arrow3,5*zz);
setVelZ(arrow3,7*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
if(smg3 == true && Player.getCarriedItem()==520)
{
var pyaw = Entity.getYaw(Player.getEntity()); 
var ppitch = Entity.getPitch(Player.getEntity());
velY = Math.sin((ppitch - 180) / 180 * Math.PI); 
velX = 3.5 * (Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
velZ = 3.5 * (-1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
var arrow = Level.spawnMob(Player.getX() + Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,Player.getY(),Player.getZ() + -1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,80);
setVelX(arrow,velX);
setVelY(arrow,velY);
setVelZ(arrow,velZ);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
else
{
smg3 = false;
}
if(smg4 == true && Player.getCarriedItem()==521)
{
var pyaw = Entity.getYaw(Player.getEntity()); 
var ppitch = Entity.getPitch(Player.getEntity());
velY = Math.sin((ppitch - 180) / 180 * Math.PI); 
velX = 3.2 * (Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
velZ = 3.2 * (-1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
var arrow = Level.spawnMob(Player.getX() + Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,Player.getY(),Player.getZ() + -1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,80);
setVelX(arrow,velX);
setVelY(arrow,velY);
setVelZ(arrow,velZ);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
else
{
smg4 = false;
}
if(smg5 == true && Player.getCarriedItem()==522)
{
var pyaw = Entity.getYaw(Player.getEntity()); 
var ppitch = Entity.getPitch(Player.getEntity());
velY = Math.sin((ppitch - 180) / 180 * Math.PI); 
velX = 3.2 * (Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
velZ = 3.2 * (-1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
var arrow = Level.spawnMob(Player.getX() + Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,Player.getY(),Player.getZ() + -1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,80);
setVelX(arrow,velX);
setVelY(arrow,velY);
setVelZ(arrow,velZ);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
else
{
smg5 = false;
}
if(smg6 == true && Player.getCarriedItem()==528)
{
var pyaw = Entity.getYaw(Player.getEntity()); 
var ppitch = Entity.getPitch(Player.getEntity());
velY = Math.sin((ppitch - 180) / 180 * Math.PI); 
velX = 3.2 * (Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
velZ = 3.2 * (-1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
var arrow = Level.spawnMob(Player.getX() + Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,Player.getY(),Player.getZ() + -1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,80);
setVelX(arrow,velX);
setVelY(arrow,velY);
setVelZ(arrow,velZ);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
else
{
smg6 = false;
}
if(smg7 == true && Player.getCarriedItem()==529)
{
var pyaw = Entity.getYaw(Player.getEntity()); 
var ppitch = Entity.getPitch(Player.getEntity());
velY = Math.sin((ppitch - 180) / 180 * Math.PI); 
velX = 5.0 * (Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
velZ = 5.0 * (-1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI)); 
var arrow = Level.spawnMob(Player.getX() + Math.sin(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,Player.getY(),Player.getZ() + -1 * Math.cos(pyaw / 180 * Math.PI) * Math.cos((ppitch - 180) / 180 * Math.PI) ,80);
setVelX(arrow,velX);
setVelY(arrow,velY);
setVelZ(arrow,velZ);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
else
{
smg7 = false;
}
if (Player.getCarriedItem() == 552 && hand == false) {
hand = true;
      ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
      try{
      var layout = new android.widget.LinearLayout(ctx);
      layout.setOrientation(1);
      
      var equis = new android.widget.Button(ctx);
      equis.setText(" ");
      equis.setWidth(500);
      equis.setHeight(500);
      var conchudo=new android.graphics.drawable.BitmapDrawable(android.graphics.BitmapFactory.decodeStream(ModPE.openInputStreamFromTexturePack("images/ComprasGUI/Mira.png")));
	  equis.setBackgroundDrawable(conchudo);
      equis.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){

      }
      }));
      layout.addView(equis);
      
      PUNTERO = new android.widget.PopupWindow(layout, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
            PUNTERO.setWidth(500);
            PUNTERO.setHeight(500);
      PUNTERO.setBackgroundDrawable(conchudo);
      
PUNTERO.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.CENTER | android.view.Gravity.CENTER, 0, 0);
      }catch(err){
      print('An error occured: ' + err);
      }
      }}));
      }
else if (Player.getCarriedItem() != 552 && hand == true) {
ctx.runOnUiThread(new java.lang.Runnable() {
run: function() {
hand = false;
PUNTERO.dismiss();
}
})
}
if (Player.getCarriedItem() == 530 && hand5 == false) {
hand5 = true;
      ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
      try{
      var layout = new android.widget.LinearLayout(ctx);
      layout.setOrientation(1);
      
      var exp = new android.widget.Button(ctx);
      exp.setText("C4");
      exp.setWidth(50);
      exp.setHeight(50);
      exp.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
if(on == true) {
Level.explode(blockx, blocky, blockz, 10);
ModPE.showTipMessage("Detonación Exitosa!");
}
      }
      }));
      layout.addView(exp);
      
      C4 = new android.widget.PopupWindow(layout, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
            C4.setWidth(90);
            C4.setHeight(90);
      C4.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      
C4.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.CENTER, 0, 0);
      }catch(err){
      print('An error occured: ' + err);
      }
      }}));
      }
else if (Player.getCarriedItem() != 530 && hand5 == true) {
ctx.runOnUiThread(new java.lang.Runnable() {
run: function() {
hand5 = false;
C4.dismiss();
}
})
}
if (Player.getCarriedItem() == 552 && hand2 == false) {
hand2 = true;
      ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
      try{
      var layout = new android.widget.LinearLayout(ctx);
      layout.setOrientation(1);
      
      var SZOOM = new android.widget.Button(ctx);
      SZOOM.setText("Zoom");
      SZOOM.setTextSize(8);
      SZOOM.setWidth(70);
      SZOOM.setHeight(40);
      SZOOM.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
if(zoom==false)
{
ModPE.setFov(30);
zoom = true;
}
else if(zoom==true)
{
ModPE.setFov(70);
zoom = false;
}
}
      }
      ));
      layout.addView(SZOOM);
      
      SNIPERZOOM = new android.widget.PopupWindow(layout, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
            SNIPERZOOM.setWidth(100);
            SNIPERZOOM.setHeight(80);
      SNIPERZOOM.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      
SNIPERZOOM.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.CENTER, 0, 65);
      }catch(err){
      print('An error occured: ' + err);
      }
      }}));
      }
else if (Player.getCarriedItem() != 552 && hand2 == true) {
ctx.runOnUiThread(new java.lang.Runnable() {
run: function() {
hand2 = false;
SNIPERZOOM.dismiss();
}
})
}
if (Player.getCarriedItem() == 588 && hand88 == false) {
hand88 = true;
      ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
      try{
      var layout = new android.widget.LinearLayout(ctx);
      layout.setOrientation(1);
      
      var EG = new android.widget.Button(ctx);
      EG.setText("Shoot");
      EG.setTextSize(8);
      EG.setWidth(70);
      EG.setHeight(40);
      EG.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
pitch = ((Entity.getPitch(getPlayerEnt()) + 90) * Math.PI) / 180;
yaw = ((Entity.getYaw(getPlayerEnt()) + 90) * Math.PI) / 180;dirx = Math.sin(pitch) * Math.cos(yaw);
diry = Math.cos(pitch);
dirz = Math.sin(pitch) * Math.sin(yaw);
Pearl = Level.dropItem(Player.getX() + dirx, Player.getY() + diry, Player.getZ() + dirz, 0, 476, 1);
ePearls.push(Pearl);
setVelY(Pearl, 4 * diry);
setVelX(Pearl, 1.3 * Math.cos((getYaw() + 90) * (Math.PI / 180)));
setVelZ(Pearl, 1.3 * Math.sin((getYaw() + 90) * (Math.PI / 180)));
}
	  }
      ));
      layout.addView(EG);
      
      ENDERGUN = new android.widget.PopupWindow(layout, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
            ENDERGUN.setWidth(100);
            ENDERGUN.setHeight(80);
      ENDERGUN.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      
ENDERGUN.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.CENTER, 0, 65);
      }catch(err){
      print('An error occured: ' + err);
      }
      }}));
      }
else if (Player.getCarriedItem() != 588 && hand88 == true) {
ctx.runOnUiThread(new java.lang.Runnable() {
run: function() {
hand88 = false;
ENDERGUN.dismiss();
}
})
}
if (Player.getCarriedItem() == 589 && hand89 == false) {
hand89 = true;
      ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
      try{
      var layout = new android.widget.LinearLayout(ctx);
      layout.setOrientation(1);
      
      var bino = new android.widget.Button(ctx);
      bino.setText("Zoom");
      bino.setTextSize(8);
      bino.setWidth(70);
      bino.setHeight(40);
      bino.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
showmainMenu();
showexit();
ModPE.setFov(20);
}
	  }
      ));
      layout.addView(bino);
      
      bin = new android.widget.PopupWindow(layout, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
            bin.setWidth(100);
            bin.setHeight(80);
      bin.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      
bin.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.CENTER, 0, 65);
      }catch(err){
      print('An error occured: ' + err);
      }
      }}));
      }
else if (Player.getCarriedItem() != 589 && hand89 == true) {
ctx.runOnUiThread(new java.lang.Runnable() {
run: function() {
hand89 = false;
bin.dismiss();
ModPE.setFov(70);
}
})
}
if (Player.getCarriedItem() == 552 && hand3 == false) {
hand3 = true;
      ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
      try{
      var layout = new android.widget.LinearLayout(ctx);
      layout.setOrientation(1);
      
      var SFIRE = new android.widget.Button(ctx);
      SFIRE.setText("Fire");
      SFIRE.setTextSize(10);
      SFIRE.setWidth(70);
      SFIRE.setHeight(40);
      SFIRE.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
var xx=Math.sin(p)*Math.cos(y); 
var yy=Math.sin(p)*Math.sin(y); 
var zz=Math.cos(p);
arrow1 = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80);
setVelX(arrow1,5*xx);
setVelY(arrow1,5*zz);
setVelZ(arrow1,5*yy);
Level.playSound(getPlayerX(), getPlayerY(), getPlayerZ(), "tile.arm.m16", 1, 0.5);
}
      }
      ));
      layout.addView(SFIRE);
      
      SNIPERFIRE = new android.widget.PopupWindow(layout, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
            SNIPERFIRE.setWidth(100);
            SNIPERFIRE.setHeight(80);
      SNIPERFIRE.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      
SNIPERFIRE.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.CENTER, 0, 0);
      }catch(err){
      print('An error occured: ' + err);
      }
      }}));
      }
else if (Player.getCarriedItem() != 552 && hand3 == true) {
ctx.runOnUiThread(new java.lang.Runnable() {
run: function() {
hand3 = false;
SNIPERFIRE.dismiss();
}
})
}
}

function jetpackTick() {
	toDirectionalVector(playerDir, (getYaw() + 90) * DEG_TO_RAD, getPitch() * DEG_TO_RAD * -1);
	var player = getPlayerEnt();
	setVelX(player, playerFlySpeed * playerDir[0]);
	setVelY(player, playerFlySpeed * playerDir[1]);
	setVelZ(player, playerFlySpeed * playerDir[2]);
}
function toDirectionalVector(vector, yaw, pitch) {
	vector[0] = Math.cos(yaw) * Math.cos(pitch);
	vector[1] = Math.sin(pitch);
	vector[2] = Math.sin(yaw) * Math.cos(pitch);
}

Item.setCategory(500, ItemCategory.TOOL);
Player.addItemCreativeInv(500,0,1);
Item.setCategory(502, ItemCategory.TOOL);
Player.addItemCreativeInv(502,0,1);
Item.setCategory(503, ItemCategory.TOOL);
Player.addItemCreativeInv(503,0,1);
Item.setCategory(505, ItemCategory.TOOL);
Player.addItemCreativeInv(505,0,1);
Item.setCategory(510, ItemCategory.TOOL);
Player.addItemCreativeInv(510,0,1);
Item.setCategory(600, ItemCategory.TOOL);
Player.addItemCreativeInv(600,0,1);
Item.setCategory(508, ItemCategory.TOOL);
Player.addItemCreativeInv(508,0,1);
Item.setCategory(515, ItemCategory.TOOL);
Player.addItemCreativeInv(515,0,1);
Item.setCategory(516, ItemCategory.TOOL);
Player.addItemCreativeInv(516,0,1);
Item.setCategory(517, ItemCategory.TOOL);
Player.addItemCreativeInv(517,0,1);
Item.setCategory(519, ItemCategory.TOOL);
Player.addItemCreativeInv(519,0,1);
Item.setCategory(520, ItemCategory.TOOL);
Player.addItemCreativeInv(520,0,1);
Item.setCategory(521, ItemCategory.TOOL);
Player.addItemCreativeInv(521,0,1);
Item.setCategory(530,ItemCategory.TOOL);
Player.addItemCreativeInv(530,0,1);
Item.setCategory(230,ItemCategory.TOOL);
Player.addItemCreativeInv(230);
Item.setCategory(522, ItemCategory.TOOL);
Player.addItemCreativeInv(522,0,1);
Item.setCategory(523,ItemCategory.TOOL);
Player.addItemCreativeInv(523,0,1);
Item.setCategory(524,ItemCategory.TOOL);
Player.addItemCreativeInv(524,0,1);
Item.setCategory(526, ItemCategory.TOOL);
Player.addItemCreativeInv(526,0,1);
Item.setCategory(527, ItemCategory.TOOL);
Player.addItemCreativeInv(527,0,1);
Item.setCategory(528, ItemCategory.TOOL);
Player.addItemCreativeInv(528,0,1);
Item.setCategory(529, ItemCategory.TOOL);
Player.addItemCreativeInv(529,0,1);
Item.setCategory(551, ItemCategory.TOOL);
Player.addItemCreativeInv(551,0,1);
Item.setCategory(552, ItemCategory.TOOL);
Player.addItemCreativeInv(552,0,1);
Item.setCategory(553, ItemCategory.TOOL);
Player.addItemCreativeInv(553,0,1);
Item.setCategory(554, ItemCategory.TOOL);
Player.addItemCreativeInv(554,0,1);
Item.setCategory(555, ItemCategory.TOOL);
Player.addItemCreativeInv(555,0,1);
Item.setCategory(556, ItemCategory.TOOL);
Player.addItemCreativeInv(556,0,1);
Item.setCategory(557, ItemCategory.TOOL);
Player.addItemCreativeInv(557,0,1);
Item.setCategory(558, ItemCategory.TOOL);
Player.addItemCreativeInv(558,0,1);
Item.setCategory(559, ItemCategory.TOOL);
Player.addItemCreativeInv(559,0,1);
Item.setCategory(560, ItemCategory.TOOL);
Player.addItemCreativeInv(560,0,1);
Item.setCategory(561, ItemCategory.TOOL);
Player.addItemCreativeInv(561,0,1);
Item.setCategory(562, ItemCategory.TOOL);
Player.addItemCreativeInv(562,0,1);
Item.setCategory(563, ItemCategory.TOOL);
Player.addItemCreativeInv(563,0,1);
Item.setCategory(564, ItemCategory.TOOL);
Player.addItemCreativeInv(564,0,1);
Item.setCategory(565, ItemCategory.TOOL);
Player.addItemCreativeInv(565,0,1);
Item.setCategory(566, ItemCategory.TOOL);
Player.addItemCreativeInv(566,0,1);
Item.setCategory(567, ItemCategory.TOOL);
Player.addItemCreativeInv(567,0,1);
Item.setCategory(568, ItemCategory.TOOL);
Player.addItemCreativeInv(568,0,1);
Item.setCategory(569, ItemCategory.TOOL); Player.addItemCreativeInv(569,0,1); Item.setCategory(570, ItemCategory.TOOL); Player.addItemCreativeInv(570,0,1); Item.setCategory(571, ItemCategory.TOOL); Player.addItemCreativeInv(571,0,1); Item.setCategory(572, ItemCategory.TOOL); Player.addItemCreativeInv(572,0,1); Item.setCategory(573, ItemCategory.TOOL); Player.addItemCreativeInv(573,0,1);
Item.setCategory(574, ItemCategory.TOOL);
Player.addItemCreativeInv(574,0,1);
Item.setCategory(575, ItemCategory.TOOL);
Player.addItemCreativeInv(575,0,1);
Item.setCategory(576, ItemCategory.TOOL);
Player.addItemCreativeInv(576,0,1);
Item.setCategory(577, ItemCategory.TOOL);
Player.addItemCreativeInv(577,0,1);
Item.setCategory(578, ItemCategory.TOOL);
Player.addItemCreativeInv(578,0,1);
Item.setCategory(579, ItemCategory.TOOL);
Player.addItemCreativeInv(579,0,1);
Item.setCategory(580, ItemCategory.TOOL);
Player.addItemCreativeInv(580,0,1);
Item.setCategory(581, ItemCategory.TOOL);
Player.addItemCreativeInv(581,0,1);
Item.setCategory(582, ItemCategory.TOOL);
Player.addItemCreativeInv(582,0,1);
Item.setCategory(583, ItemCategory.TOOL);
Player.addItemCreativeInv(583,0,1);
Item.setCategory(584, ItemCategory.TOOL);
Player.addItemCreativeInv(584,0,1);
Item.setCategory(585, ItemCategory.TOOL);
Player.addItemCreativeInv(585,0,1);
Item.setCategory(586, ItemCategory.TOOL);
Player.addItemCreativeInv(586,0,1);
Item.setCategory(587, ItemCategory.TOOL);
Player.addItemCreativeInv(587,0,1);
Item.setCategory(588, ItemCategory.TOOL);
Player.addItemCreativeInv(588,0,1);
Item.setCategory(476, ItemCategory.TOOL);
Player.addItemCreativeInv(476,0,1);
Item.setCategory(589, ItemCategory.TOOL);
Player.addItemCreativeInv(589,0,1);

function deathHook(murder, victim) {
if (Entity.getEntityTypeId(victim) == 38) {
Level.dropItem(Entity.getX(victim), Entity.getY(victim), Entity.getZ(victim), 0, 476, 1);
}
}

function entityAddedHook(e){
if(Entity.getNameTag(e)=="[NPC] Trader"){
Entity.setMobSkin(e, "mobs/SkinTrader.png");
Entity.setRenderType(e,traderRenderType.renderType);
Entity.addEffect(e, MobEffect.movementSpeed,1000123*20, 9, false, true);
Entity.addEffect(e,MobEffect.jump,300*20,1,false,true);
}
}

function attackHook(a, v) {
	if (Entity.getEntityTypeId(v) == 20) { 
        preventDefault(); 
		
		mainMenu();
		exit();
    }
}




//**Compras Background**//
var menuC; var CexitUI;

function mainMenu(){
      var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
      try{
      var menuLayout = new android.widget.LinearLayout(ctx);
      var menuScroll = new android.widget.ScrollView(ctx);
      var menuLayout1 = new android.widget.LinearLayout(ctx);
      menuLayout.setOrientation(1);
      menuLayout1.setOrientation(1);
      menuScroll.addView(menuLayout);
      menuLayout1.addView(menuScroll);
	  
	  var tradeText = new android.widget.TextView(ctx);
	  tradeText.setGravity(android.view.Gravity.CENTER);
	  var tradeTextBackground=new android.graphics.drawable.BitmapDrawable(android.graphics.BitmapFactory.decodeStream(ModPE.openInputStreamFromTexturePack("images/ComprasGUI/MinecraftButtonPush.png")));
	  tradeText.setBackgroundDrawable(tradeTextBackground);
	  var rnd = Math.floor(Math.random()*(compras.length)); 
	  tradeText.setText("Por " + compras[rnd][0][2] + " " + compras[rnd][0][0] + " Obtienes " + compras[rnd][1][2] + " " + compras[rnd][1][0]);
	  tradeText.setTextColor(android.graphics.Color.WHITE);
				
	  menuLayout.addView(tradeText);
    
	 var tradeButton = new android.widget.Button(ctx);
				tradeButton.setText("Comprar");
				var tradeIMG=new android.graphics.drawable.BitmapDrawable(android.graphics.BitmapFactory.decodeStream(ModPE.openInputStreamFromTexturePack("images/ComprasGUI/MinecraftButton.png")));
				tradeButton.setBackgroundDrawable(tradeIMG);
				tradeButton.setTextColor(android.graphics.Color.GREEN);
				tradeButton.setOnClickListener(new android.view.View.OnClickListener() {
					onClick: function(v) {
						if (Level.getGameMode() == 1 || invContains(compras[rnd][0][1], compras[rnd][0][2])) { 
							invDeduct(compras[rnd][0][1], compras[rnd][0][2]);
							Player.addItemInventory(compras[rnd][1][1], compras[rnd][1][2], 0);
							print("Compra Realizada!");
						} else {
							print("No Tienes Lo Suficiente!");
						}
						menuC.dismiss();
						menuC = null;
						CexitUI.dismiss();
						CexitUI = null;
					}
				});
				
	  menuLayout.addView(tradeButton);
      
      menuC = new android.widget.PopupWindow(menuLayout1, ctx.getWindowManager().getDefaultDisplay().getWidth()/2, ctx.getWindowManager().getDefaultDisplay().getHeight());
	  menuC.setHeight(720);
	  menuC.setWidth(1280);
	  var ruta = ModPE.openInputStreamFromTexturePack("images/ComprasGUI/back.png");
	  var imajen = android.graphics.BitmapFactory.decodeStream(ruta);
      imajen= android.graphics.Bitmap.createBitmap(imajen,0,0,16,16);
	  imejen= android.graphics.Bitmap.createScaledBitmap(imajen,1024,1024,false);
      menuC.setBackgroundDrawable(new android.graphics.drawable.BitmapDrawable(imajen));
      menuC.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.TOP, 0, 0);
      }catch(error){
      print('An error occured: ' + error);
      }
      }}));
      }
      
//**Exit Btn**//
      function exit(){
      var ctxe = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      ctxe.runOnUiThread(new java.lang.Runnable({ run: function(){
      try{
      var xLayout = new android.widget.LinearLayout(ctxe);
      var xButton = new android.widget.Button(ctxe);
      xButton.setText('');
	  var zorras1=new android.graphics.drawable.BitmapDrawable(android.graphics.BitmapFactory.decodeStream(ModPE.openInputStreamFromTexturePack("images/ComprasGUI/xButton.png")));
	  xButton.setBackgroundDrawable(zorras1);
      xButton.setTextColor(android.graphics.Color.WHITE);
      xButton.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      CexitUI.dismiss();
      menuC.dismiss();
      }
      }));
      xLayout.addView(xButton);
      CexitUI = new android.widget.PopupWindow(xLayout, dip2px(40), dip2px(40));
      CexitUI.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
	  CexitUI.setHeight(75);
	  CexitUI.setWidth(75);
      CexitUI.showAtLocation(ctxe.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.CENTER, 0, 0);
      }catch(exception){
      print(exception);
      }
      }}));
      }

//**Contains**//
function invContains(itemId, count) {
	var hasItem = false; 
	
	for (var i = 0; i < 36; i++) {
		if (Player.getInventorySlot(i) == itemId && Player.getInventorySlotCount(i) >= count) {
			hasItem = true;
			break; 
		}
	}
	
	return hasItem;
}

function invDeduct(itemId, count) {
	var didDeduct = false; 
	
	for (var i = 0; i < 36; i++) {
		if (Player.getInventorySlot(i) == itemId && Player.getInventorySlotCount(i) >= count) {
			var remainder = Player.getInventorySlotCount(i) - count;
			Player.clearInventorySlot(i);
			Player.addItemInventory(itemId, remainder, 0);
		
			didDeduct = true;
			break; 
		}
	}
	
	return didDeduct;
}

//**Zoom Menu - User Interface**//
function dip2px(dips){
      var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      return Math.ceil(dips * ctx.getResources().getDisplayMetrics().density);
      }

function showmainMenu(){
      var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
      try{
      var menuLayout = new android.widget.LinearLayout(ctx);
      var menuScroll = new android.widget.ScrollView(ctx);
      var menuLayout1 = new android.widget.LinearLayout(ctx);
      menuLayout.setOrientation(1);
      menuLayout1.setOrientation(1);
      menuScroll.addView(menuLayout);
      menuLayout1.addView(menuScroll);
      
      NPCmenu = new android.widget.PopupWindow(menuLayout1, ctx.getWindowManager().getDefaultDisplay().getWidth()/2, ctx.getWindowManager().getDefaultDisplay().getHeight());
      NPCmenu.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.BLACK));
	  NPCmenu.setWidth(1280);
      NPCmenu.setHeight(720);
      var ekis=new android.graphics.drawable.BitmapDrawable(android.graphics.BitmapFactory.decodeStream(ModPE.openInputStreamFromTexturePack("images/ComprasGUI/zoom.png")));
	  NPCmenu.setBackgroundDrawable(ekis);
      NPCmenu.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.CENTER | android.view.Gravity.TOP, 0, 0);
      }catch(error){
      print('An error occured: ' + error);
      }
      }}));
      }
      function showexit(){
      var ctxe = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      ctxe.runOnUiThread(new java.lang.Runnable({ run: function(){
      try{
      var xLayout = new android.widget.LinearLayout(ctxe);
      var xButton = new android.widget.Button(ctxe);
      xButton.setText('X');
      xButton.setTextColor(android.graphics.Color.WHITE);
      xButton.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      NPCexitUI.dismiss();
      NPCmenu.dismiss();
	  ModPE.setFov(70);
      }
      }));
      xLayout.addView(xButton);
      NPCexitUI = new android.widget.PopupWindow(xLayout, dip2px(40), dip2px(40));
      NPCexitUI.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      NPCexitUI.showAtLocation(ctxe.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.CENTER, 0, 0);
      }catch(exception){
      print(exception);
      }
      }}));
      }
